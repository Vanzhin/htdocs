<?php
define('ROOT', dirname(__DIR__));
define('DS', DIRECTORY_SEPARATOR);
define('CONTROLLER_NAMESPACE', "app\\controllers\\");
define('VIEWS_DIR', "../views/");
define('TWIG_TEMPLATES_DIR', "../templates/");
define('ITEMS_PER_PAGE', 2);


