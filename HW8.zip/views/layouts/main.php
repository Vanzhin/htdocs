<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="/style/style.css"/>
</head>
<body>
<?=$menu?>
<?=$content?>
<?=$footer?>
</body>
</html>
