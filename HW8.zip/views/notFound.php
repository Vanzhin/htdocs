<div id="main">
    <div class="post_title"><h2>Страница не найдена</h2></div>
</div>
