<div class="footer">
<?=$date?>
</div>
